

# Albo degli studenti anno 1 - 2021/2024

NB: che le immagini siano tutte JPG di dimensione massima 256x256 

## Progetti
| Titolo | Team | Repo |
|---|---|---|
| titolo | team | url |

## Docenti
|   | Nome | Corso | Team | Url |
|:---:|---|---|---|---|
|![](./data/FrancescoLanzo/avatar-lanzo-bn-256.jpg) | Francesco Lanzo | Programming | - | [GitHub](https://github.com/franz0) </br> [GitLab](https://gitlab.com/franzo) </br>[Twitter](https://twitter.com/develoop_)|
|![](./data/IlariaBaldassari/IlariaBaldassari.jpg) | Ilaria Baldassari | Cumulative | - | [GitHub](https://github.com/SheiraFenix) </br> [ArtStation](https://www.artstation.com/sheirafenix)|
|![](./data/StefanoCecere/StefanoCecere.jpg) | Stefano Cecere | Cumulative | - | [GitHub](https://github.com/StefanoCecere)|
|![](./data/VincenzoSantalucia/VincenzoSantalucia.jpg) | Vincenzo Santalucia | GameDesign | - | [GitHub](https://github.com/loSceiccoBeige) </br> [Website](https://www.vincenzosantalucia.design/)|


## Programming
|   | Nome | Corso | Team | Url |
|:---:|---|---|---|---|
|![](./data/AlessioBolognesi/AlessioBolognesi.jpg) | nome cognome | Programming | team name | [GitHub](https://github.com/Bolognesi-Alessio)|
|![]() | Marco Chechi | Programming | team Cutman | [Github](https://github.com/Licantropo5)|
|![]() | Luca Gunnella | Programming | team bomberman | [GitHub](https://github.com/LucaGunnella)|
|![]() | Leonardo Martelli | Programming | Team Elecman | [GitHub](https://github.com/LeonardoMartelli-coba)|
|![]()| Moreno Melis| Programming | Team Fireman | [GitHub](https://github.com/MorenoMelis)|

## Game Design
|   | Nome | Corso | Team | Url |
|:---:|---|---|---|---|
|![](./data/DavideGioan/DavideGioan.jpg) | nome cognome | Game Design | team name | [GitHub](https://github.com/GioanDavide)|
|![](./data/AndreaCianfanelli/Cinfa.jpg) | Andrea Cianfanelli |  | Cutman | [GitHub](https://github.com/cinfa78)|
|![](./data/AlbertoSargenti/AlbertoSargentiAvatar.jpg) | Alberto Sargenti | Game Design | FireMan | [GitHub](https://github.com/AlbertoSargenti)|
|![](./data/LuigiGrassini/LuigiGrassiniFoto.jpg) | Luigi Grassini | Game Design | FireMan | [GitHub](https://github.com/Hemsey7)|
|![](./data/FrancescoPieruccini/FrancescoPieruccini.jpg) | Francesco Pieruccini | Game Design | GutsMan | [GitHub](https://github.com/FrancescoPieruccini)|
|![](./data/FrancescoNannini/NanniniFrancesco.jpg) | Francesco Nannini | Game Design | Bombman | [GitHub](https://github.com/BelethThynemenos)|
|![](./data/AndreaVanghi/AndreaVanghi.jpg) | Andrea Vanghi | Game Design | Gutsman | [GitHub](https://github.com/VanghiAndrea)|

## Concept Art
|   | Nome | Corso | Team | Url |
|:---:|---|---|---|---|
|![](./data/MatildaGori/MatildaGori.jpg) | Matilda Gori | Concept Art | Fireman | [GitHub](https://github.com/MatildaGori) </br> [ArtStation](https://www.artstation.com/uf12bbec5)|
|![](./data/AlbertoBandini/cropped.jpg) | nome cognome | Concept Art | team name | [GitHub](https://github.com/zeboo-svg)|
|![]()| Maria Libera Demarcus| Concept Art | Team Bombman | [GitHub](https://github.com/Weeliox)|
![]()| Michele Gabrielli | Concept Art | Team Bombman | [GitHub](https://github.com/MicheleGabrielli)|
|![]()| Lorenzo Ferraina | Concept Art | Team Elecman | [GitHub](https://github.com/Lorenzo-Ferraina)|
|![](./data/MattiaMonteduro/MattiaMonteduro.jpg)| Mattia Monteduro | Concept Art | Team Bombman | [GitHub](https://github.com/MattiaMonteduro)|
|![]()| Claudio Zappi | Concept Art | Team Fireman | [GitHub](https://github.com/Claudio-Zappi)|
|![](./data/AlessioRuggeri/AlessioRuggeri.jpg)| Alessio Ruggeri | Concept Art | Gutsman | [GitHub](https://github.com/AlessioRuggeri5)|
|![]()| Mirco Paoli | Concept Art | Team Elecman | [GitHub](https://github.com/PaoliMirco-art)|


## 3D Game Art
|   | Nome | Corso | Team | Url |
|:---:|---|---|---|---|
|![](./data/FrancescoLaiali/PFP.jpg) | Francesco Laiali | 3D Game Art | team name | [GitHub](https://github.com/FrancescoLaiali)
|![](./data/BenedettaBaccari/BenedettaBaccari.jpg) | nome cognome | 3D Game Art | team name | [GitHub](https://github.com/cipincipancake)
|![](./data/BenedettaBaccari/BenedettaBaccari.jpg) | Matteo Ledda | 3D Game Art | BombMan | [GitHub](https://github.com/MatteoLedda)
|![](./data/MarcoGazzaniga/Marco_Gazzaniga.jpg) | Marco Gazzaniga | 3D Game Art | BombMan | [GitHub](https://github.com/MarcoGazzaniga)
|![](./data/ContiAsiaLara/ContiAsiaLara.jpg) | Conti Asia Lara Giovanna | 3D Game Art | Gutsman | [GitHub](https://github.com/ContiAsiaLara)
